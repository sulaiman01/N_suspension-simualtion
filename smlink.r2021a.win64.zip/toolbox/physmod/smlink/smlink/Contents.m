% Simscape Multibody Link
% Version 7.3 (R2021a) 14-Nov-2020

%   Copyright 2007-2020 The MathWorks, Inc.
